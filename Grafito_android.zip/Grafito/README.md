# Grafito — primer incremento Android

Galería Android nativa en Kotlin + Jetpack Compose. Identidad «Editorial Carbón», nombre y paquete aprobados (`Grafito` / `com.grafito.gallery`). Este ZIP contiene el **proyecto fuente**, no un APK listo para instalar.

## Qué incluye este primer incremento

- Estructura Android Studio/Gradle con minSdk 30, targetSdk 35 y Compose.
- Lectura de fotos y videos visibles para la app a través de MediaStore.
- Permisos modernos de Android; en Android 14+ acepta acceso parcial a fotos/videos.
- Cuadrícula de fotos/videos, detalle informativo básico y selección múltiple (pulsación larga).
- Papelera operativa con selección múltiple, restauración y eliminación permanente.
- Registro local SQLite de la fecha de envío a papelera y vencimiento a 30 días.
- Primeras pantallas en español con paleta carbón/grafito/marfil y acento latón.
- Tipografías Inter y Playfair Display, más el ícono de fotos apiladas.
- Documentación funcional y visual en `docs/`.

## Regla de la papelera — requisito cerrado

Al eliminar, Grafito solicita al sistema Android mover el medio a la papelera usando `MediaStore.createTrashRequest`. Android muestra su confirmación del sistema y gestiona el período de retención de **30 días**. Antes del vencimiento, la app permite marcar varios archivos y escoger **RESTAURAR** o **ELIMINAR PARA SIEMPRE**; borrar permanentemente también requiere la confirmación del sistema. El registro local guarda `deleted_at` y `expires_at`; al abrir la papelera, Grafito elimina del índice local los registros vencidos. Un archivo purgado o eliminado permanentemente ya no puede restaurarse desde Grafito.

El diseño usa la papelera del sistema, no una copia privada propia; así se evita duplicar el archivo y se mantiene la integración del dispositivo. El comportamiento de retención corresponde a Android MediaStore en Android 11 o posterior.

## Abrir y compilar

Requisitos: Android Studio reciente, JDK 17, Android SDK 35. La primera sincronización necesita internet para descargar Gradle y dependencias.

```bash
# En Linux/macOS, desde esta carpeta
./gradlew assembleDebug
```

En Windows: `gradlew.bat assembleDebug`. También se puede abrir la carpeta `Grafito/` desde Android Studio y dejar que Gradle sincronice.

> **Estado de validación:** el wrapper Gradle 8.9 está incluido. No fue posible completar la compilación dentro de este entorno: usa Java 11 y la conexión Java→Maven falló por negociación TLS. La compilación deberá verificarse al sincronizar en Android Studio con JDK 17 y acceso a Google Maven/Maven Central. No se incluye APK.

## Lo que sigue en construcción

Este es el **primer corte funcional**, no la versión completa acordada. La base de selección y papelera ya está iniciada; quedan por integrar/probar el visor de pantalla completa y gesto «pasaporte», gaveta privada con clave, bloqueo, tema claro/automático, álbumes/búsqueda, etiquetas editables y funciones completas de metadata. La pantalla «Toda la metadata» muestra por ahora campos de archivo e información de dimensiones; el lector EXIF/XMP/IPTC, edición/limpieza de fotos y detección de texto oculto aún no se implementan. Videos quedan previstos para lectura solamente en v1.

La persistencia inicial usa SQLiteOpenHelper local (`GrafitoDb`) para reducir dependencias; la especificación de producto conserva Room como opción para la capa de persistencia completa.

## Privacidad

La app no incorpora analítica ni subida de fotos. Android solicita permiso de acceso al medio y puede limitarlo a una selección parcial. Las acciones de papelera/borrado usan los diálogos de consentimiento del sistema.
