package com.grafito.gallery.media

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.grafito.gallery.data.GrafitoDb
import com.grafito.gallery.data.MediaEntry

class MediaRepository(private val context: Context, private val db: GrafitoDb) {
    fun loadMedia(videos: Boolean? = null): List<MediaEntry> =
        (if (videos == null || !videos) query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false) else emptyList()) +
        (if (videos == null || videos) query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true) else emptyList())

    private fun query(collection: android.net.Uri, video: Boolean): List<MediaEntry> {
        val resolver = context.contentResolver
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.RELATIVE_PATH)
        val result = mutableListOf<MediaEntry>()
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        resolver.query(collection, projection, null, null, sort)?.use { cursor ->
            val idIx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idIx)
                val uri = ContentUris.withAppendedId(collection, id)
                val name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)) ?: "Sin título"
                val mime = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)) ?: ""
                val size = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE))
                val w = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH))
                val h = cursor.getInt(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT))
                val modified = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)) * 1000
                val added = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)) * 1000
                val pathIx = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                val path = if (pathIx >= 0) cursor.getString(pathIx).orEmpty() else ""
                result += MediaEntry(id, uri, name, mime, size, w, h, modified, 0L, path, video)
            }
        }
        return result
    }
    fun tags(uri: String) = db.tags(uri)
}
