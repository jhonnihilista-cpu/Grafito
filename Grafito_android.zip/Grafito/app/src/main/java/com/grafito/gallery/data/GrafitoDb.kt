package com.grafito.gallery.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class GrafitoDb(context: Context) : SQLiteOpenHelper(context, "grafito.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE trash(uri TEXT PRIMARY KEY, name TEXT NOT NULL, mime TEXT, size INTEGER, width INTEGER, height INTEGER, deleted_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, is_video INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE tags(uri TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(uri, tag))")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun addToTrash(item: MediaEntry, now: Long = System.currentTimeMillis()) {
        val cv = ContentValues().apply {
            put("uri", item.uri.toString()); put("name", item.name); put("mime", item.mime)
            put("size", item.size); put("width", item.width); put("height", item.height)
            put("deleted_at", now); put("expires_at", now + TRASH_LIFETIME_MS)
            put("is_video", if (item.isVideo) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("trash", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun trashItems(): List<TrashEntry> {
        val out = mutableListOf<TrashEntry>()
        readableDatabase.rawQuery("SELECT uri,name,mime,size,width,height,deleted_at,expires_at,is_video FROM trash ORDER BY deleted_at DESC", null).use { c ->
            while (c.moveToNext()) out += TrashEntry(c.getString(0), c.getString(1), c.getString(2) ?: "application/octet-stream", c.getLong(3), c.getInt(4), c.getInt(5), c.getLong(6), c.getLong(7), c.getInt(8) == 1)
        }
        return out
    }
    fun removeTrash(uris: Collection<String>) {
        writableDatabase.beginTransaction()
        try { uris.forEach { writableDatabase.delete("trash", "uri=?", arrayOf(it)) }; writableDatabase.setTransactionSuccessful() }
        finally { writableDatabase.endTransaction() }
    }
    fun pruneExpired(now: Long = System.currentTimeMillis()): List<TrashEntry> {
        val expired = trashItems().filter { it.expiresAt <= now }
        if (expired.isNotEmpty()) removeTrash(expired.map { it.uri })
        return expired
    }
    fun tags(uri: String): List<String> {
        val out = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT tag FROM tags WHERE uri=? ORDER BY tag", arrayOf(uri)).use { c -> while(c.moveToNext()) out += c.getString(0) }
        return out
    }
    fun setTags(uri: String, tags: List<String>) {
        val db = writableDatabase; db.beginTransaction()
        try {
            db.delete("tags", "uri=?", arrayOf(uri))
            tags.take(5).map { it.trim() }.filter { it.isNotEmpty() }.distinct().forEach { tag ->
                db.insert("tags", null, ContentValues().apply { put("uri", uri); put("tag", tag) })
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    companion object { const val TRASH_LIFETIME_MS = 30L * 24 * 60 * 60 * 1000 }
}
