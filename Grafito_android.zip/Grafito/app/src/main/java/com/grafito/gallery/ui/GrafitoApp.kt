package com.grafito.gallery.ui

import android.text.format.Formatter
import androidx.compose.foundation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.grafito.gallery.MediaAction
import com.grafito.gallery.R
import com.grafito.gallery.data.MediaEntry
import com.grafito.gallery.data.TrashEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Coal = Color(0xFF131316)
private val Graphite = Color(0xFF1B1B1F)
private val Stone = Color(0xFF232329)
private val Smoke = Color(0xFF2E2E35)
private val WarmGray = Color(0xFFA8A6A0)
private val Ivory = Color(0xFFEDEBE6)
private val Brass = Color(0xFFB8A176)
private val Playfair = FontFamily(Font(R.font.playfair_display, FontWeight.Normal))
private val Inter = FontFamily(Font(R.font.inter, FontWeight.Normal), Font(R.font.inter, FontWeight.Medium))

@Composable
fun GrafitoApp(
    hasPermission: Boolean,
    mediaLoader: suspend () -> List<MediaEntry>,
    trashLoader: suspend () -> List<TrashEntry>,
    tagLoader: (String) -> List<String>,
    onRequestPermission: () -> Unit,
    onMediaAction: (List<MediaEntry>, MediaAction) -> Unit,
    onTrashAction: (List<TrashEntry>, MediaAction) -> Unit,
    actionResult: Boolean?,
    actionNonce: Int,
    onActionHandled: () -> Unit
) {
    var tab by remember { mutableStateOf("Fotos") }
    var mode by remember { mutableStateOf("Fotos") }
    var media by remember { mutableStateOf(emptyList<MediaEntry>()) }
    var trash by remember { mutableStateOf(emptyList<TrashEntry>()) }
    val selected = remember { mutableStateListOf<String>() }
    val selectedTrash = remember { mutableStateListOf<String>() }
    var detail by remember { mutableStateOf<MediaEntry?>(null) }
    var showAllMetadata by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var refreshToken by remember { mutableIntStateOf(0) }
    var handledActionNonce by remember { mutableIntStateOf(0) }

    LaunchedEffect(hasPermission, refreshToken, actionNonce, tab) {
        if (hasPermission) {
            busy = true
            media = withContext(Dispatchers.IO) { mediaLoader() }
            trash = withContext(Dispatchers.IO) { trashLoader() }
            busy = false
        }
        if (actionNonce > handledActionNonce) {
            handledActionNonce = actionNonce
            onActionHandled()
            selected.clear(); selectedTrash.clear()
            refreshToken++
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Brass, onPrimary = Coal, background = Coal, surface = Graphite,
        onSurface = Ivory, secondary = WarmGray, surfaceVariant = Stone
    )) {
        Surface(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars), color = Coal) {
            when {
                !hasPermission -> PermissionScreen(onRequestPermission)
                detail != null -> DetailScreen(detail!!, tagLoader(detail!!.uri.toString()),
                    onBack = { detail = null }, onFull = { showAllMetadata = true })
                tab == "Ajustes" -> SettingsScreen(onBack = { tab = "Fotos" })
                tab == "Papelera" -> TrashScreen(
                    items = trash,
                    selected = selectedTrash,
                    onSelect = { item -> toggle(selectedTrash, item.uri) },
                    onBack = { tab = "Fotos"; selectedTrash.clear() },
                    onRestore = { selectedTrash.mapNotNull { id -> trash.find { it.uri == id } }.takeIf { it.isNotEmpty() }?.let { onTrashAction(it, MediaAction.RESTORE) } },
                    onDelete = { selectedTrash.mapNotNull { id -> trash.find { it.uri == id } }.takeIf { it.isNotEmpty() }?.let { onTrashAction(it, MediaAction.PERMANENT_DELETE) } },
                    busy = busy
                )
                else -> GalleryScreen(
                    tab = tab,
                    mode = mode,
                    media = media,
                    selected = selected,
                    busy = busy,
                    onMode = { mode = it; selected.clear() },
                    onTab = { tab = it; selected.clear() },
                    onSelect = { item -> toggle(selected, item.uri.toString()) },
                    onOpen = { item -> detail = item },
                    onRefresh = { refreshToken++ },
                    onTrash = {
                        selected.mapNotNull { id -> media.find { it.uri.toString() == id } }
                            .takeIf { it.isNotEmpty() }?.let { onMediaAction(it, MediaAction.TRASH) }
                    }
                )
            }
            if (showAllMetadata && detail != null) {
                MetadataDialog(detail!!, onDismiss = { showAllMetadata = false })
            }
        }
    }
}

private fun toggle(list: MutableList<String>, id: String) {
    if (id in list) list.remove(id) else list.add(id)
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(30.dp), verticalArrangement = Arrangement.Center) {
        Text("Grafito", fontFamily = Playfair, fontSize = 38.sp, color = Ivory)
        Spacer(Modifier.height(12.dp))
        Text("Tu biblioteca, en calma.", color = WarmGray, fontFamily = Inter, fontSize = 15.sp)
        Spacer(Modifier.height(32.dp))
        Text("Para mostrar tus fotos y videos, permite el acceso a contenido multimedia. Grafito no sube tus archivos a ningún servidor.", color = Ivory, lineHeight = 23.sp)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest, colors = ButtonDefaults.buttonColors(containerColor = Brass, contentColor = Coal), shape = RoundedCornerShape(14.dp)) {
            Text("PERMITIR ACCESO", fontFamily = Inter, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun GalleryScreen(
    tab: String, mode: String, media: List<MediaEntry>, selected: List<String>, busy: Boolean,
    onMode: (String) -> Unit, onTab: (String) -> Unit, onSelect: (MediaEntry) -> Unit,
    onOpen: (MediaEntry) -> Unit, onRefresh: () -> Unit, onTrash: () -> Unit
) {
    val filtered = when (mode) {
        "Videos" -> media.filter { it.isVideo }
        else -> media.filterNot { it.isVideo }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 16.dp, top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Grafito", fontFamily = Playfair, fontSize = 32.sp, color = Ivory)
                Text("FOTOGRAFÍA · EN SU LUGAR", fontFamily = Inter, fontSize = 9.sp, letterSpacing = 2.sp, color = WarmGray)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Actualizar", tint = WarmGray) }
            IconButton(onClick = { onTab("Ajustes") }) { Icon(Icons.Default.Settings, "Ajustes", tint = WarmGray) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeChip("Fotos", mode == "Fotos") { onMode("Fotos") }
            ModeChip("Videos", mode == "Videos") { onMode("Videos") }
            Spacer(Modifier.weight(1f))
            Text("${filtered.size}", color = WarmGray, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))
        }
        Spacer(Modifier.height(14.dp))
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size} seleccionados", color = Ivory, modifier = Modifier.weight(1f), fontFamily = Inter)
                TextButton(onClick = { onTrash() }) { Icon(Icons.Default.DeleteOutline, null, tint = Brass); Spacer(Modifier.width(4.dp)); Text("A papelera", color = Brass) }
            }
        }
        when {
            busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Brass) }
            filtered.isEmpty() -> EmptyState("Aún no hay ${mode.lowercase()} aquí", "Tus archivos multimedia aparecerán en esta galería.", Modifier.weight(1f))
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3), modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 2.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filtered, key = { it.uri.toString() }) { item ->
                    MediaTile(item, selected.contains(item.uri.toString()), onSelect, onOpen)
                }
            }
        }
        BottomNav(tab, onTab)
    }
}

@Composable
private fun ModeChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, color = if (active) Brass else Stone, shape = RoundedCornerShape(24.dp)) {
        Text(label.uppercase(), modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), fontSize = 10.sp,
            letterSpacing = 1.3.sp, fontFamily = Inter, fontWeight = FontWeight.Medium,
            color = if (active) Coal else WarmGray)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MediaTile(item: MediaEntry, isSelected: Boolean, onSelect: (MediaEntry) -> Unit, onOpen: (MediaEntry) -> Unit) {
    Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(5.dp)).background(Stone)
        .combinedClickable(onClick = { if (isSelected) onSelect(item) else onOpen(item) }, onLongClick = { onSelect(item) })) {
        AsyncImage(model = item.uri, contentDescription = item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (item.isVideo) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.align(Alignment.Center).size(29.dp))
        if (isSelected) Box(Modifier.fillMaxSize().background(Brass.copy(alpha = .34f)))
        if (isSelected) Icon(Icons.Default.CheckCircle, null, tint = Brass, modifier = Modifier.align(Alignment.TopEnd).padding(7.dp).size(21.dp))
    }
}

@Composable
private fun BottomNav(current: String, onTab: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Graphite).navigationBarsPadding().padding(horizontal = 14.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceAround) {
        NavItem("Fotos", Icons.Default.GridView, current == "Fotos") { onTab("Fotos") }
        NavItem("Papelera", Icons.Default.DeleteOutline, current == "Papelera") { onTab("Papelera") }
        NavItem("Ajustes", Icons.Default.Tune, current == "Ajustes") { onTab("Ajustes") }
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (active) Brass else WarmGray, modifier = Modifier.size(21.dp))
        Text(label, fontFamily = Inter, fontSize = 10.sp, color = if (active) Brass else WarmGray)
    }
}

@Composable
private fun TrashScreen(items: List<TrashEntry>, selected: List<String>, onSelect: (TrashEntry) -> Unit,
                       onBack: () -> Unit, onRestore: () -> Unit, onDelete: () -> Unit, busy: Boolean) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Ivory) }
            Column(Modifier.weight(1f)) {
                Text("Papelera", fontFamily = Playfair, fontSize = 27.sp, color = Ivory)
                Text("SE ELIMINAN AUTOMÁTICAMENTE A LOS 30 DÍAS", fontFamily = Inter, fontSize = 8.sp, color = WarmGray, letterSpacing = 1.sp)
            }
            Text("${items.size}", color = Brass, fontFamily = Inter)
        }
        Surface(color = Stone, shape = RoundedCornerShape(14.dp), modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
            Text("Puedes restaurar elementos antes de que venza el plazo, o eliminarlos de forma permanente ahora.", color = WarmGray, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(13.dp))
        }
        if (selected.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size} seleccionados", color = Ivory, modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = onRestore) { Text("RESTAURAR", color = Brass, fontSize = 10.sp) }
                TextButton(onClick = onDelete) { Text("ELIMINAR PARA SIEMPRE", color = Color(0xFFE2A49B), fontSize = 9.sp) }
            }
        }
        when {
            busy -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Brass) }
            items.isEmpty() -> EmptyState("La papelera está vacía", "Los elementos que elimines permanecerán aquí durante 30 días.", Modifier.weight(1f))
            else -> androidx.compose.foundation.lazy.LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(items, key = { it.uri }) { item -> TrashRow(item, selected.contains(item.uri), { onSelect(item) }) }
            }
        }
        BottomNav("Papelera", {})
    }
}

@Composable
private fun TrashRow(item: TrashEntry, selected: Boolean, onClick: () -> Unit) {
    val context = LocalContext.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (selected) Smoke else Graphite).clickable(onClick = onClick).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(67.dp).clip(RoundedCornerShape(8.dp)).background(Stone)) {
            AsyncImage(item.contentUri, item.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (item.isVideo) Icon(Icons.Default.PlayArrow, null, tint = Ivory, modifier = Modifier.align(Alignment.Center))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, color = Ivory, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text("${item.daysLeft()} días restantes · ${Formatter.formatFileSize(context, item.size)}", color = Brass, fontSize = 10.sp)
            Text("Eliminado ${formatDate(item.deletedAt)}", color = WarmGray, fontSize = 10.sp)
        }
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Brass)
    }
}

@Composable
private fun DetailScreen(item: MediaEntry, tags: List<String>, onBack: () -> Unit, onFull: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Ivory) }
            Text("Información", fontFamily = Playfair, fontSize = 25.sp, color = Ivory)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFull) { Icon(Icons.Default.List, "Toda la metadata", tint = Brass) }
        }
        Box(Modifier.fillMaxWidth().weight(.85f).padding(horizontal = 12.dp).clip(RoundedCornerShape(12.dp)).background(Stone), contentAlignment = Alignment.Center) {
            AsyncImage(item.uri, item.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            if (item.isVideo) Icon(Icons.Default.PlayCircle, null, tint = Color.White.copy(alpha = .9f), modifier = Modifier.size(54.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 16.dp)) {
            Text(item.name, color = Ivory, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(12.dp))
            InfoLine("Modificada", formatDate(item.modifiedAt))
            InfoLine("Tamaño", Formatter.formatFileSize(context, item.size))
            InfoLine("Resolución", if (item.width > 0) "${item.width} × ${item.height}" else "No disponible")
            InfoLine("Tipo", item.mime.ifBlank { if (item.isVideo) "Video" else "Imagen" })
            InfoLine("Ruta", item.relativePath.ifBlank { "Biblioteca multimedia" })
            Spacer(Modifier.height(12.dp))
            Text("ETIQUETAS · ${tags.size}/5", color = Brass, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Text(tags.joinToString("  ·  ").ifBlank { "Sin etiquetas" }, color = WarmGray, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onFull, border = BorderStroke(1.dp, Brass.copy(alpha = .65f)), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text("MOSTRAR TODA LA METADATA", color = Brass, letterSpacing = 1.sp, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun MetadataDialog(item: MediaEntry, onDismiss: () -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(color = Graphite, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 650.dp)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Toda la metadata", fontFamily = Playfair, color = Ivory, fontSize = 24.sp)
                        Text(item.name, color = WarmGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Cerrar", tint = WarmGray) }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    MetadataGroup("ARCHIVO", listOf("Nombre" to item.name, "Tipo" to item.mime, "Tamaño" to Formatter.formatFileSize(context, item.size), "Modificada" to formatDate(item.modifiedAt), "Ruta" to item.relativePath))
                    MetadataGroup("IMAGEN / VIDEO", listOf("Ancho" to px(item.width), "Alto" to px(item.height), "Resolución" to if (item.width > 0) "${item.width} × ${item.height}" else "No disponible", "Formato" to item.mime))
                    MetadataGroup("DESCRIPCIÓN", listOf("Título" to "—", "Autor" to "—", "Comentarios" to "—"))
                    MetadataGroup("ORIGEN / CAPTURA", listOf("Fecha de captura" to "No disponible en esta versión", "Cámara" to "No disponible en esta versión"))
                    MetadataGroup("GPS", listOf("Ubicación" to "No disponible en esta versión"))
                    Spacer(Modifier.height(12.dp))
                    Text("AVANZADA · SEGURIDAD", color = Brass, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text("Lectura de XMP/IPTC y detección de texto oculto se incorporarán en la siguiente iteración del lector de metadata.", color = WarmGray, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 7.dp))
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("CERRAR", color = Brass) }
            }
        }
    }
}

@Composable
private fun MetadataGroup(title: String, rows: List<Pair<String, String>>) {
    Text(title, color = WarmGray, fontFamily = Inter, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 15.dp, bottom = 5.dp))
    rows.forEach { (label, value) ->
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(label, color = WarmGray, fontSize = 11.sp, modifier = Modifier.weight(.8f))
            Text(value, color = Ivory, fontSize = 11.sp, modifier = Modifier.weight(1.2f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        HorizontalDivider(color = Smoke, thickness = .5.dp)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(label, color = WarmGray, fontSize = 12.sp, modifier = Modifier.weight(.8f))
        Text(value, color = Ivory, fontSize = 12.sp, modifier = Modifier.weight(1.2f), maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Volver", tint = Ivory) }
            Text("Ajustes", fontFamily = Playfair, fontSize = 28.sp, color = Ivory)
        }
        Spacer(Modifier.height(18.dp))
        Text("APARIENCIA", color = Brass, fontSize = 10.sp, letterSpacing = 1.8.sp)
        SettingRow("Tema", "Oscuro · Carbón y latón")
        SettingRow("Tema claro", "En construcción")
        Spacer(Modifier.height(22.dp))
        Text("PRIVACIDAD", color = Brass, fontSize = 10.sp, letterSpacing = 1.8.sp)
        SettingRow("Bloqueo de la app", "Desactivado por defecto")
        SettingRow("Gaveta", "Sección privada · configuración pendiente")
        SettingRow("Papelera", "Eliminación automática a los 30 días")
        Spacer(Modifier.height(22.dp))
        Text("Grafito · versión 1.0.0", color = WarmGray, fontSize = 11.sp)
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 11.dp)) {
        Text(title, color = Ivory, fontSize = 14.sp)
        Text(subtitle, color = WarmGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        HorizontalDivider(color = Smoke, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun EmptyState(title: String, message: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.PhotoLibrary, null, tint = Brass.copy(alpha = .8f), modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, color = Ivory, fontFamily = Playfair, fontSize = 21.sp)
        Spacer(Modifier.height(6.dp))
        Text(message, color = WarmGray, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

private fun formatDate(time: Long): String = if (time <= 0L) "—" else SimpleDateFormat("d MMM yyyy · HH:mm", Locale("es", "VE")).format(Date(time))
private fun px(value: Int) = if (value > 0) "$value px" else "—"
