package com.grafito.gallery.data

import android.net.Uri

data class MediaEntry(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val modifiedAt: Long,
    val dateTaken: Long,
    val relativePath: String,
    val isVideo: Boolean
)

data class TrashEntry(
    val uri: String,
    val name: String,
    val mime: String,
    val size: Long,
    val width: Int,
    val height: Int,
    val deletedAt: Long,
    val expiresAt: Long,
    val isVideo: Boolean
) {
    val contentUri: Uri get() = Uri.parse(uri)
    fun daysLeft(now: Long = System.currentTimeMillis()): Int =
        (((expiresAt - now).coerceAtLeast(0L) + 86_400_000L - 1) / 86_400_000L).toInt()
}
