package com.grafito.gallery

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import com.grafito.gallery.data.GrafitoDb
import com.grafito.gallery.data.MediaEntry
import com.grafito.gallery.data.TrashEntry
import com.grafito.gallery.media.MediaRepository
import com.grafito.gallery.ui.GrafitoApp

class MainActivity : ComponentActivity() {
    private lateinit var db: GrafitoDb
    private lateinit var repository: MediaRepository
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = GrafitoDb(this)
        repository = MediaRepository(this, db)
        setContent {
            var permissionGranted by remember { mutableStateOf(hasMediaPermission()) }
            val permissionsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                permissionGranted = hasMediaPermission()
            }
            val actionResult = remember { mutableStateOf<Boolean?>(null) }
            val actionNonce = remember { mutableIntStateOf(0) }
            val actionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
                actionResult.value = result.resultCode == RESULT_OK
                actionNonce.intValue++
            }
            GrafitoApp(
                hasPermission = permissionGranted,
                mediaLoader = { repository.loadMedia().sortedByDescending { it.modifiedAt } },
                trashLoader = { db.pruneExpired(); db.trashItems() },
                tagLoader = repository::tags,
                onRequestPermission = {
                    permissionsLauncher.launch(mediaPermissions())
                },
                onMediaAction = { items, action ->
                    val uris = items.map { it.uri }.distinct()
                    if (uris.isNotEmpty()) {
                        val pending: PendingIntent = when (action) {
                            MediaAction.TRASH -> MediaStore.createTrashRequest(contentResolver, uris, true)
                            MediaAction.RESTORE -> MediaStore.createTrashRequest(contentResolver, uris, false)
                            MediaAction.PERMANENT_DELETE -> MediaStore.createDeleteRequest(contentResolver, uris)
                        }
                        pendingAction = action
                        pendingMedia = items
                        pendingTrash = emptyList()
                        actionLauncher.launch(IntentSenderRequest.Builder(pending.intentSender).build())
                    }
                },
                onTrashAction = { items, action ->
                    val uris = items.map { it.contentUri }.distinct()
                    if (uris.isNotEmpty() && action != MediaAction.TRASH) {
                        val pending = when (action) {
                            MediaAction.RESTORE -> MediaStore.createTrashRequest(contentResolver, uris, false)
                            MediaAction.PERMANENT_DELETE -> MediaStore.createDeleteRequest(contentResolver, uris)
                            MediaAction.TRASH -> null
                        }
                        pending?.let {
                            pendingAction = action
                            pendingMedia = emptyList()
                            pendingTrash = items
                            actionLauncher.launch(IntentSenderRequest.Builder(it.intentSender).build())
                        }
                    }
                },
                actionResult = actionResult.value,
                actionNonce = actionNonce.intValue,
                onActionHandled = {
                    if (actionResult.value == true) {
                        when (pendingAction) {
                            MediaAction.TRASH -> pendingMedia.forEach { db.addToTrash(it) }
                            MediaAction.RESTORE, MediaAction.PERMANENT_DELETE -> db.removeTrash(pendingTrash.map { it.uri })
                            null -> Unit
                        }
                    }
                    actionResult.value = null
                    pendingAction = null
                    pendingMedia = emptyList()
                    pendingTrash = emptyList()
                }
            )
        }
    }

    private var pendingAction: MediaAction? = null
    private var pendingMedia: List<MediaEntry> = emptyList()
    private var pendingTrash: List<TrashEntry> = emptyList()

    private fun hasMediaPermission(): Boolean = mediaPermissions().any {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }.let { granted ->
        if (Build.VERSION.SDK_INT >= 34) {
            granted || ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED
        } else granted
    }

    private fun mediaPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
}

enum class MediaAction { TRASH, RESTORE, PERMANENT_DELETE }
