# Especificación funcional — **Grafito** · «Editorial Carbón» · v0.3

> Documento vivo · 20 de octubre de 2026 · Entrega: proyecto Android en ZIP descargable
> Objetivo: replicar la funcionalidad de «Galería de fotos y álbum» (Mobile_V5)
> con las modificaciones acordadas. Android nativo (propuesta: Kotlin + Jetpack).

## 1. Pantallas
| # | Pantalla | Contenido |
|---|---|---|
| 1 | **Inicio — Álbumes** | Encabezado (lupa, «+», **ajustes**), accesos Recientes/Videos/Favoritos/**Gaveta**, cuadrícula de álbumes (portada, nombre, «N elementos»). Sin gaveta en la lista. |
| 2 | **Fotos — Línea de tiempo** | Cuadrícula agrupada por día; navegador de mes; videos con duración; favoritos marcados. |
| 3 | **Visor** | Foto/video a pantalla completa + gestos «pasaporte» (§3) + hoja de información (§4). |
| 4 | **Gaveta** | Ventana de clave de 5 dígitos → contenido privado (§5). |
| 5 | **Ajustes** | Tema (Claro/Oscuro/Automático) · Bloqueo de app (interruptor, off por defecto) · Clave de la gaveta · Papelera · Excluir carpetas · Acerca de. |
| 6 | **Carga** | Teseractos anidados, líneas marfil, zoom eterno (4,8 s loop). |
| — | *Papelera, Búsqueda, Selector de carpeta, Editor básico* | Heredan el estilo; se detallarán al construir. |

## 2. Funcionalidad base (heredada de la app de referencia)
- Explorar fotos/videos por fecha, álbum y carpeta; soporte multi-tarjeta SD.
- Álbumes inteligentes: Recientes, Videos, Favoritos; álbumes por carpeta.
- Crear/renombrar/mover/copiar/eliminar; compartir; ver detalles.
- Papelera de reciclaje (restaurar).
- Favoritos; presentación (slideshow); visor con gestos de zoom/rotación.
- Excluir carpetas de la galería.
- (Se omite del alcance v1: editor avanzado, collages, «historias», anuncios/compras.)

## 3. Visor — gestos «estilo pasaporte»
- **Deslizar derecha→izquierda:** la foto actual **se pliega por la mitad** (efecto
  página de pasaporte) revelando la siguiente. **La velocidad del gesto determina
  la velocidad de la transición** (mapear velocidad de fling → duración de la
  animación de plegado). Terminología técnica: `ViewPager2` + `PageTransformer`
  personalizado (plegado 3D) o render propio con `GLSurfaceView` si se exige más
  realismo (sombra de pliegue).
- **Deslizar izquierda→derecha:** vuelve la fotografía anterior (plegado inverso).
- **Deslizar abajo→arriba:** abre la **hoja de información** (§4).
- **Deslizar arriba→abajo:** envía la foto a la **papelera** con confirmación
  ligera (snackbar «Enviado a la papelera — Deshacer»). No es borrado permanente.
- PELLIZCO: zoom (heredado).

## 4. Hoja «Información», metadata y etiquetas
- **Vista rápida** (↑ abre la hoja; estilo de la app original): Título,
  Modificada, Tamaño, Resolución, Cámara, Ubicación, Ruta + **etiquetas**.
- **Etiquetas: hasta 5 por foto/video**, guardadas en **base de datos local
  (Room)** —búsqueda instantánea, sin reescribir archivos—.
- **MOSTRAR TODA LA METADATA**: visor exhaustivo estilo *Windows › Propiedades
  › Detalles* (grupos Propiedad|Valor: Archivo, Imagen, Descripción, Origen,
  Captura, GPS, **Avanzada·Seguridad**), desplazable.
- **Avanzada·Seguridad** (latón): revela paquete XMP, UserComment (EXIF),
  segmentos APPn y **alerta si hay texto no visible** —vector conocido de
  «inyección» (publicidad/instrucciones) hacia IAs que leen el archivo—.
- **EDITAR (fotos):** fecha, ubicación/GPS, descripción, autor vía
  `ExifInterface` (JPEG sólido; PNG/WebP parcial).
- **LIMPIAR (fotos):** ① *Quitar datos sensibles* — GPS, dispositivo, autor,
  comentarios (EXIF selectivo); ② *Eliminar toda la metadata* — re-codifica el
  archivo (garantía total contra texto oculto; calidad ≈ 95 %, se avisa al usuario).
- **Videos:** lectura completa de metadata (`MediaMetadataRetriever`); edición
  y limpieza **no** en v1 (requiere re-mux; se evalúa en v2).
- **Decisión (niveles de satisfacción):** ver fotos/videos ≈ 95 % ✓ ·
  editar+limpiar fotos ≈ 85 % ✓ (≥ 70 % → **Opción 1**) · editar/limpiar
  videos ≈ 30 % ✗ → solo visualización.

## 5. Gaveta (sección privada renombrada)
- **Una sola gaveta oculta**, equivalentes funcionales de «Privado» de la app
  original: mover fotos/videos a la gaveta (se ocultan de la galería principal),
  cifrado/bloqueo por clave, sacar de la gaveta.
- **Clave de 5 dígitos.** Primera vez: crear clave + pregunta de seguridad
  (herencia de la app original). Recuperación por pregunta de seguridad.
- La gaveta **no aparece** en «Mis álbumes»; se abre solo desde el acceso directo.
- Cambio de clave en Ajustes › Seguridad › Clave de la gaveta.

## 6. Bloqueo de la app
- Interruptor en Ajustes › Seguridad › **Bloqueo de la app** — **desactivado por defecto**.
- Activado: solicita clave (misma infraestructura de clave, distinta de la de la gaveta)
  al iniciar la app (pantalla de clave estilo visor, teclado serif).

## 7. Búsqueda
- Busca por: nombre de archivo, etiquetas (§4), álbum, carpeta, ubicación y fecha.
- Las **etiquetas** tienen prioridad de relevancia para «localizar la foto de mejor manera».

## 8. Temas
- Tres modos: **Claro · Oscuro · Automático** (predeterminado: Automático o Oscuro — por decidir).
- Oscuro: monocromo + latón. Claro: papel + acentos aureola (ver guía de estilo).
- Tokens de color centralizados (`MaterialTheme` personalizado) para ambos temas.

## 9. Papelera — retención cerrada por la usuaria
- Al elegir **Eliminar**, la foto o video se **mueve a Papelera**, no se
  destruye inmediatamente.
- Cada elemento permanece allí **30 días desde su eliminación**; al vencer,
  se borra **automática y permanentemente**. No existe restauración pasada la
  fecha de vencimiento.
- Desde Papelera se puede seleccionar **uno o varios** elementos y escoger
  **Restaurar** o **Eliminar de forma permanente**.
- Tras el borrado permanente manual o automático, el elemento deja de ser
  recuperable desde Grafito.
- Implementación Android inicial: *MediaStore trash requests* (Android 11+),
  con diálogo de confirmación del sistema; Android gestiona el plazo de purga
  de 30 días. Grafito conserva un índice local de fechas de borrado/plazo y
  lo depura al vencer. No duplicamos el archivo en almacenamiento privado.


## 10. Permisos (Android moderno)
- `READ_MEDIA_IMAGES` / `READ_MEDIA_VIDEO` (+ `READ_MEDIA_VISUAL_USER_SELECTED`
  para acceso parcial en Android 14+).
- `ACCESS_FINE_LOCATION` solo si el usuario quiere ver ubicaciones EXIF.
- `MANAGE_EXTERNAL_STORAGE` **no** es objetivo (acceso parcial + SAF para
  operaciones en carpetas elegidas); heredar clave de la app original solo si es imprescindible.

## 12. Estado de construcción (primer incremento Android)
- Proyecto fuente: `Grafito/` (Kotlin + Jetpack Compose, `minSdk 30`, target 35).
- Ya iniciados: exploración de fotos/videos con MediaStore; cuadrícula y
  selección múltiple; Papelera mediante solicitudes nativas de MediaStore;
  registro local de vencimiento y flujos de restauración/borrado permanente;
  primera vista de información; estilo oscuro inicial.
- Pendiente de integración: gaveta, bloqueo, visor pasaporte, búsqueda/álbumes,
  editor/limpiador y lectura real de EXIF/XMP/IPTC, etiquetas editables, tema
  claro/automático y validación en dispositivo.
- La especificación describe el producto objetivo; `Grafito/README.md` identifica
  con precisión qué está implementado en este primer corte y qué falta.

## 11. Pendientes de decisión
1. ¿Modo de presentación (slideshow) en v1?
2. ~~Nombre~~ → **Grafito** ✓ · ~~Entrega~~ → **ZIP descargable** ✓
3. ~~Papelera~~ → **30 días + restauración / eliminación permanente selectiva** ✓
