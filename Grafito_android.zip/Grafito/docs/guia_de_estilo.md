# Grafito — Guía de estilo «Editorial Carbón» · v3

> 20 de octubre de 2026 · Nombre aprobado: **Grafito** · Entrega: ZIP descargable
> Base funcional: «Galería de fotos y álbum» (Mobile_V5) con rebranding propio.

## 1. Concepto
Una galería sobria y elegante, como una revista de fotografía impresa: fondos
carbón, serif editorial, hairlines finas y líneas marfil lumínicas. Dos temas:
**oscuro** monocromo con acento **latón (aprobado)**, y **claro «aureola»** con
detalles de color inspirados en la aurora boreal (referencias del usuario).

## 2. Temas (3 opciones convencionales)
- **Oscuro** (identidad principal)
- **Claro «aureola»**
- **Automático** — sigue el tema del dispositivo

### 2.1 Paleta · Tema OSCURO — monocromo + latón ✓
| Uso | Nombre | HEX |
|---|---|---|
| Fondo de app | Carbón | `#131316` |
| Superficies (tarjetas, teclado, hoja info) | Grafito | `#1B1B1F` |
| Chips, teclas, elementos elevados | Piedra | `#232329` |
| Hairlines y bordes 1 dp | Humo | `#2E2E35` |
| Texto principal / líneas lumínicas | Marfil | `#EDEBE6` |
| Texto secundario | Gris cálido | `#A8A6A0` |
| Texto terciario | Gris piedra | `#6E6C68` |
| **Acento (aprobado)** — acciones, «EDITAR», glifos de gestos | **Latón** | `#B8A176` |

**Regla:** ~90 % carbón/grafito, ~9 % marfil, ≤1 % latón.

### 2.2 Paleta · Tema CLARO «aureola»
| Uso | Nombre | HEX |
|---|---|---|
| Fondo | Papel | `#F7F4ED` |
| Tarjetas | Blanco | `#FFFFFF` |
| Texto | Tinta | `#232220` |
| Texto secundario | Gris cálido claro | `#6E6A62` |
| Hairlines | Humo claro | `#E1DDD3` |
| Acento aurora | Teal | `#2BB39E` |
| Acento | Azul | `#4A72D8` |
| Acento | Violeta | `#8B6FD8` |
| Acento | Coral | `#D95F4C` |
| Acento | Dorado | `#D9A648` |

**Gradiente «aureola»** (aurora boreal): teal → azul → violeta → magenta → dorado.
Usos: lavado suave tras el encabezado, línea de 2–3 dp bajo el título, chip
activo (dorado suave `#F3E9CF`), enlaces en teal. Los colores aparecen como
*detalles*; el conjunto sigue siendo editorial y sereno.

## 3. Tipografía
- **Títulos y numerales:** Playfair Display 600 («Álbumes», «Gaveta», dígitos del teclado).
- **Interfaz y datos:** Inter 400–600.
- **Versalitas espaciadas** para sobrelíneas/secciones: «COLECCIÓN», «MIS ÁLBUMES»,
  «HOY · LUNES 14», «CARGANDO», «INFORMACIÓN».
- Textos de UI siempre en español: *elementos, clave, etiquetas, papelera…*

## 4. Formas y componentes
- Radios: tarjetas 10–14 dp · teclas 16 dp · ícono de app ~24 %.
- Hairlines 1 dp; elevación por tono, no por sombra.
- Encabezado del inicio: **lupa + «+» + engranaje (ajustes)**.
- Accesos: **Recientes · Videos · Favoritos · Gaveta**.
- Cuadrícula de álbumes: portada 170×128 + nombre + «N elementos».
  **La gaveta NO aparece entre los álbumes** (gaveta oculta).
- Visor: foto a pantalla completa; barra superior mínima; **hoja de información**
  deslizable (Nombre, Ubicación, Dimensiones, Detalles + **5 etiquetas**).
- Interruptores y segmentos (Claro/Oscuro/Automático) en estilo hairline.

## 5. La Gaveta (ex «Privado»)
- **Una sola gaveta**, oculta, con las mismas funciones de la sección privada
  original (baúl/cifrado, mover fotos a privado, etc.).
- Flujo: tocar el acceso «Gaveta» → ventana de **clave de 5 dígitos** → se abre
  la gaveta (ventana privada). Primera vez: crear clave (y recuperación).
- **No** existen gavetas múltiples. No figura en «Mis álbumes».
- Clave gestionable en Ajustes › Seguridad.

## 6. Bloqueo de la app
- Interruptor **activable/desactivable** en Ajustes › Seguridad.
- **Desactivado por defecto.** Al activarlo, pide la clave al abrir la app.

## 7. Navegación del visor — «estilo pasaporte»
- **‹ ›** (derecha→izquierda): la foto **se pliega por la mitad** y deja ver la
  siguiente; **la velocidad del gesto manda**. Inverso = foto anterior.
- **↑** (abajo→arriba): abre la **hoja «Información»** (§7.1).
- **↓** (arriba→abajo): **envía a la papelera**; permanece allí 30 días,
  luego se elimina automática y permanentemente. Antes de vencer, se puede
  restaurar o eliminar de forma permanente de manera selectiva.

### 7.1 Información y metadata (v3)
- **Vista rápida** (hoja inferior, estilo app original): Título, Modificada,
  Tamaño, Resolución, Cámara, Ubicación, Ruta + **5 etiquetas**.
- Acciones: **EDITAR** y **LIMPIAR** (latón).
- **MOSTRAR TODA LA METADATA ▾**: lista exhaustiva en grupos Propiedad|Valor
  estilo Windows (Archivo, Imagen, Descripción, Origen, Captura, GPS,
  **Avanzada·Seguridad** en latón con alerta de texto oculto XMP/IPTC).
- **LIMPIAR METADATA** (diálogo): ① Quitar datos sensibles (GPS, dispositivo,
  autor, comentarios) ② Eliminar toda la metadata (re-codifica la foto).
- Fotos: edición y limpieza ≈ 85 % de satisfacción → **Opción 1 implementada**.
  Videos: solo visualización en v1 (≈ 30 % la edición).

## 8. Animación de carga
- Teseractos anidados en líneas marfil lumínicas sobre carbón; giro 4D agitado
  y **zoom eterno**; bucle perfecto 4,8 s · 30 fps.
- Archivos: `animacion_carga_teseracto.mp4` / `.gif` (sin cambios en v2).

## 9. Marcador gráfico
- Ícono del usuario: **fotos instantáneas apiladas** (monocromo; temporal o
  definitivo).
- **Nombre aprobado: Grafito** (sin colisiones relevantes en búsqueda rápida;
  verificar al publicar).

## 10. Pendientes
1. Construir y validar visor pasaporte, edición/limpieza de metadata, Gaveta,
   bloqueo, búsqueda y tema claro.
2. ¿Slideshow en v1?

## 11. Papelera (decisión cerrada)
- Retención **30 días** desde la fecha de eliminación.
- Acciones multi-selección: **Restaurar** o **Eliminar de forma permanente**.
- Al vencer el plazo, borrado automático e irreversible; no hay restauración.
